import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/gestures.dart';
import 'package:provider/provider.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';


void main() {
  runApp(
      ChangeNotifierProvider(
        create: (context) => CartNotifier(),
        child: MyApp()),
  );
}

class MyApp extends StatelessWidget {
  final Future<FirebaseApp> _initialization = Firebase.initializeApp();
  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
        future: _initialization,
        builder: (context, snapshot){
            if (snapshot.hasError){
                return Text('Something went wrong');
            }
            if (snapshot.connectionState == ConnectionState.done){
                return MaterialApp(
                    title: 'LKLBUY', 
                    initialRoute: '/', 
                    routes: {
                        '/': (context) => Login_state(),
                        '/signup': (context) => SignUp(),
                        '/homepage': (context) => Homepage(),
                        '/productinfo': (context) => ProductInfo(),
                        '/mycart': (context) => CartState(),
                    }
                );
            }
            return Loading_screen();
        }
    );
    
  }
}

class Loading_screen extends StatelessWidget{
    
    @override
    Widget build(BuildContext context){
        return Scaffold(
            body: Center(
                child: Container(
                    decoration: BoxDecoration(
                    color: const Color(0xffFBAED2),),
                    child: Container(
                        height: 173,
                        margin: EdgeInsets.symmetric(vertical: 35),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            boxShadow: [
                            BoxShadow(color: Colors.red, blurRadius: 6.0),
                            ],
                        ),
                        child: Image.asset("asset/lkl.png", height: 200, width: 200),
                    ),
                ),
            ),
        );
    }
}
//1st PAGE
class Login_state extends StatefulWidget {
  @override
  Login createState() => new Login();
}

class Login extends State<Login_state> {
  final _formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          child: Container(
            decoration: BoxDecoration(
              color: const Color(0xffFBAED2),
            ),
            child: Column(
              children: <Widget>[
                Container(
                  height: 173,
                  margin: EdgeInsets.symmetric(vertical: 35),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: [
                      BoxShadow(color: Colors.red, blurRadius: 6.0),
                    ],
                  ),
                  child: Image.asset("asset/lkl.png", height: 200, width: 200),
                ),
                Container(
                  height: MediaQuery.of(context).size.height * 0.50,
                  //width: MediaQuery.of(context).size.width * 1.0,
                  margin: EdgeInsets.symmetric(horizontal: 20.0),
                  decoration: BoxDecoration(
                    color: const Color(0xffFBAED2),
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: [
                      BoxShadow(color: Colors.red, blurRadius: 6.0),
                    ],
                  ),
                  child: Column(
                    children: <Widget>[
                      Padding(
                        padding: EdgeInsets.all(16.0),
                        child: Form(
                          key: _formKey,
                          child: Column(
                            children: <Widget>[
                              TextFormField(
                                decoration: InputDecoration(
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.all(
                                        Radius.circular(10.0),
                                      ),
                                    ),
                                    prefixIcon: Icon(Icons.person),
                                    filled: true,
                                    fillColor: Colors.pinkAccent[100],
                                    hintText: 'Username'),
                                validator: (username) {
                                  if (username.isEmpty) {
                                    return 'Username is required';
                                  }
                                  return null;
                                },
                              ),
                              SizedBox(height: 15),
                              TextFormField(
                                obscureText: true,
                                decoration: InputDecoration(
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.all(
                                        Radius.circular(10.0),
                                      ),
                                    ),
                                    prefixIcon: Icon(Icons.lock_outline),
                                    filled: true,
                                    fillColor: Colors.pinkAccent[100],
                                    hintText: 'Password'),
                                validator: (password) {
                                  if (password.isEmpty) {
                                    return 'Please Input Password';
                                  }
                                  return null;
                                },
                              ),
                              Container(
                                height: 70,
                                width: 160,
                                padding: EdgeInsets.symmetric(vertical: 16.0),
                                child: RaisedButton(
                                  textColor: Colors.white,
                                  color: Color(0xffF64A8A),
                                  onPressed: () {
                                    Navigator.pushNamed(context, '/homepage');
                                    if (_formKey.currentState.validate()) {
                                      //mga pachuychuy nato diri mga part
                                    }
                                  },
                                  child: Text('Login',
                                      style: TextStyle(fontSize: 25)),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      InputChip(
                        label: Text('Create account here',
                            style: TextStyle(color: Colors.blue)),
                        onPressed: () {
                          Navigator.pushNamed(context, '/signup');
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

//2nd PAGE
class SignUp extends StatelessWidget {
  final _formKey = GlobalKey<FormState>();
  FirebaseFirestore firestore = FirebaseFirestore.instance;
  String fullName;
  var userName;
  var passWord;
  var rePass;

  //SignUp(this.fullName,this.userName,this.passWord);

  Widget build(BuildContext context) {
    CollectionReference users = firestore.collection('users');

    Future<void> newUser(){
        return users 
            .add({
                'Fullname' : fullName,
                'Username' : userName,
                'Password' : passWord,
            })
            .then((value) => print('User added!'))
            .catchError((error) => print('Failed to add user: $error'));
    }
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          child: Container(
            decoration: BoxDecoration(
              color: const Color(0xffFBAED2),
            ),
            child: Column(
              children: <Widget>[
                Row(children: <Widget>[
                  Stack(
                    alignment: Alignment.topLeft,
                    children: <Widget>[
                      IconButton(
                        icon: Icon(Icons.arrow_back),
                        onPressed: () {
                          Navigator.pop(context);
                        },
                      ),
                    ],
                  ),
                ]),
                Center(
                  child: SingleChildScrollView(
                    child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          SizedBox(
                            height: 50.0,
                          ),
                          CircleAvatar(
                            backgroundColor: Colors.red[400],
                            radius: 50.0,
                          ),
                          Padding(
                            padding: EdgeInsets.symmetric(
                                vertical: 16.0, horizontal: 16.0),
                            child: Divider(),
                          ),
                          Padding(
                            padding: EdgeInsets.symmetric(
                                vertical: 16.0, horizontal: 16.0),
                            child: Form(
                          key: _formKey,
                          child: Column(
                            children: <Widget>[
                              TextFormField(
                                decoration: InputDecoration(
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.all(
                                        Radius.circular(10.0),
                                      ),
                                    ),
                                    prefixIcon: Icon(Icons.person),
                                    filled: true,
                                    fillColor: Colors.pinkAccent[100],
                                    hintText: 'Fullname'),
                                validator: (name) {
                                  if (name.isEmpty) {
                                    return "Fullname is required";
                                  }
                                  fullName = name;
                                },
                              ),
                              SizedBox(height: 15),
                              TextFormField(
                                decoration: InputDecoration(
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.all(
                                        Radius.circular(10.0),
                                      ),
                                    ),
                                    prefixIcon: Icon(Icons.person),
                                    filled: true,
                                    fillColor: Colors.pinkAccent[100],
                                    hintText: 'Username'),
                                validator: (username) {
                                  if (username.isEmpty) {
                                    return "Username is required";
                                  }
                                  userName = username;
                                },
                              ),
                              SizedBox(height: 15),
                              TextFormField(
                                obscureText: true,
                                decoration: InputDecoration(
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.all(
                                        Radius.circular(10.0),
                                      ),
                                    ),
                                    prefixIcon: Icon(Icons.lock_outline),
                                    filled: true,
                                    fillColor: Colors.pinkAccent[100],
                                    hintText: 'Password'),
                                validator: (password) {
                                  if (password.isEmpty) {
                                    return 'Please Input Password';
                                  }
                                  passWord = password;
                                },
                              ),
                              SizedBox(height: 15),
                              TextFormField(
                                  obscureText: true,
                                  decoration: InputDecoration(
                                      border: OutlineInputBorder(
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(10.0),
                                          ),
                                      ),
                                      prefixIcon: Icon(Icons.lock_outline),
                                      filled: true,
                                      fillColor: Colors.pinkAccent[100],
                                      hintText: 'Re-enter password'),
                                  validator: (re_pass){
                                      if (re_pass.isEmpty){
                                          return 'Please re-type password';
                                      }
                                      if (re_pass != passWord){
                                          return "Passwords must match";
                                      }
                                      rePass = re_pass;
                                  }

                                ),
                              Container(
                                height: 70,
                                width: 160,
                                padding: EdgeInsets.symmetric(vertical: 16.0),
                                child: RaisedButton(
                                  textColor: Colors.white,
                                  color: Color(0xffF64A8A),
                                  onPressed: () {
                                    if (_formKey.currentState.validate()) {
                                      _formKey.currentState.save();
                                      if(rePass == passWord && userName !=null){
                                          newUser;
                                          Navigator.pushNamed(context, '/homepage');
                                      }
                                    } 
                                  },
                                  child: Text('Confirm',
                                      style: TextStyle(fontSize: 25)),
                                ),
                              ),
                            ],
                          ),
                         ),
                        ),
                    ]),
                  ),
                ),
              ],),
            ),
        ),),
    );
  }
}

//3rd PAGE
class Homepage extends StatefulWidget {
  @override
  _HomepageState createState() => _HomepageState();
}

class _HomepageState extends State<Homepage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: new AppBar(
        //elevation: 0.0
        backgroundColor: Colors.pink,
        title: Text('LKLBUY'),
        actions: <Widget>[
          new IconButton(
              icon: Icon(
                Icons.search,
                color: Colors.white,
              ),
              onPressed: () {}),
          new IconButton(
              icon: Icon(
                Icons.shopping_cart,
                color: Colors.white,
              ),
              onPressed: () {
                  Navigator.pushNamed(context, '/mycart');
              })
        ],
      ),
      drawer: new Drawer(
        child: new ListView(
          children: <Widget>[
            //    header
            new UserAccountsDrawerHeader( 
                decoration: BoxDecoration(
                    color: Colors.pink,
                ),
                accountName: Text('Cris Orot'),
                accountEmail: Text('orot.cris1@gmail.com')),
            RichText(
              text: TextSpan(
                  style: TextStyle(color: Colors.grey, fontSize: 20.0),
                  children: [
                    TextSpan(
                        text: 'Log Out',
                        style: TextStyle(color: Colors.blue),
                        recognizer: TapGestureRecognizer()
                          ..onTap = () {
                            Navigator.pushNamed(context, '/');
                          })
                  ]),
            ),
          ],
        ),
      ),
      body: new ListView(
        children: <Widget>[
          new Padding(
            padding: const EdgeInsets.all(20.0),
            child: new Text('Location: Cagayan de Oro, Philippines'),
          ),
          Container(
            height: 570.0,
            child: Products(),
          ),
        ],
      ),
    );
  }
}

//Gridddd

class Products extends StatefulWidget {
  @override
  ProductsState createState() => ProductsState();
}

class ProductsState extends State<Products> {
  
  @override
  Widget build(BuildContext context) {
      List<Single_prod> items = all_products();
      return GridView.builder(
        itemCount: items.length,
        gridDelegate:
            new SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
        itemBuilder: (BuildContext context, int index) {
          return Card(
            child: Hero(
                tag: items[index].prod_name,
                child: Material(
                    child: InkWell(
                    onTap: () {
                        Navigator.pushNamed(context, '/productinfo');
                    },
                    child: GridTile(
                        footer: Container(
                            color: Colors.white70,
                            child: ListTile(
                                leading:Text(
                                    items[index].prod_name,
                                    style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                                title: Text(
                                    "P${items[index].prod_price.toStringAsFixed(0)}",
                                    style: TextStyle(
                                        color: Colors.red, fontWeight: FontWeight.w800,
                                    ),
                                ),
                                subtitle: IconButton(
                                    icon: Icon(Icons.add_circle, color: Colors.pink),      
                                    onPressed: () {
                                        Provider.of<CartNotifier>(context).add(items[index]);
                                        Scaffold.of(context).showSnackBar(
                                            SnackBar(content: Text('${items[index].prod_name} is added to cart'))
                                        );
                                    }, 
                                ),
                            ),
                        ),
                    child: Image.asset(
                            items[index].prod_pricture,
                            fit: BoxFit.cover,
                        ),
                    ),
              ),
            ),
            ),
          );
        }
     );

  }
  List<Single_prod> all_products(){
      return [
          Single_prod('Jacket Chan1','images/jacket.jpg',120,80),
          Single_prod('Jacket Chan2','images/jacket.jpg',120,90),
          Single_prod('Jacket Chan3','images/jacket.jpg',120,100),
          Single_prod('Jacket Chan4','images/jacket.jpg',120,150),
          Single_prod('Jacket Chan5','images/jacket.jpg',120,200),
          Single_prod('Jacket Chan6','images/jacket.jpg',120,175),
          Single_prod('Jacket Chan7','images/jacket.jpg',120,220),
          Single_prod('Jacket Chan8','images/jacket.jpg',120,300),
          Single_prod('Jacket Chan9','images/jacket.jpg',120,120),
          Single_prod('Jacket Chan10','images/jacket.jpg',120,420),
      ];
  }
}

class Single_prod{
  var prod_name;
  var prod_pricture;
  var prod_old_price;
  var prod_price;

  Single_prod(
    this.prod_name,
    this.prod_pricture,
    this.prod_old_price,
    this.prod_price,
  ); 
}

//4th PAGE
class ProductInfo extends StatefulWidget {
  ProductInfo({Key key, this.title}) : super(key: key);

  final String title;
  
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<ProductInfo> {
  String selected = "blue";
  bool favourite = false;
  ProductsState product = new ProductsState();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //The whole application area
      body: SafeArea(
        child: Column(
          children: <Widget>[
            hero(),
            spaceVertical(20),
            //Center Items
            Expanded(
              child: sections(),
            ),
          ],
        ),
      ),
    );
  }

  Widget hero() {
    return Container(
      padding: EdgeInsets.all(2),
      child: Stack(
        children: <Widget>[
          Image.asset(
            'images/jacket.jpg',
          ), //This
          // should be a paged
          // view.
          Positioned(
            child: appBar(),
            top: 0,
          ),
          Positioned(
            child: FloatingActionButton(
                elevation: 2,
                child: Image.asset(
                  favourite
                      ? "images/heart_icon.png"
                      : "images/heart_icon_disabled.png",
                  width: 30,
                  height: 30,
                ),
                backgroundColor: Colors.white,
                onPressed: () {
                  setState(() {
                    favourite = !favourite;
                  });
                }),
            bottom: 0,
            right: 20,
          ),
        ],
      ),
    );
  }

  Widget appBar() {
    return Container(
      padding: EdgeInsets.all(16),
      width: MediaQuery.of(context).size.width,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          GestureDetector(
            onTap: () {
              Navigator.pop(context);
            },
            child: Image.asset("images/back_button.png"),
          ),
          Container(
            child: Column(
              children: <Widget>[
                Text(
                  "LKLBUY STORE",
                  style: TextStyle(
                      fontWeight: FontWeight.w100,
                      color: Color(0xFFD46149),
                      fontSize: 14),
                ),
                Text(
                    'Jacket Chan',
                  style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFFD46149)),
                ),
              ],
            ),
          ),
          Image.asset(
            'images/bag_button.png',
            width: 27,
            height: 30,
          ),
        ],
      ),
    );
  }

  /***** End */

  ///************ SECTIONS  *************************************************/
  Widget sections() {
    return Container(
      padding: EdgeInsets.all(16),
      child: Column(
        children: <Widget>[
          description(),
          spaceVertical(50),
          property(),
        ],
      ),
    );
  }

  Widget description() {
    return Text(
      "In publishing and graphic design, Lorem ipsum is a  "
      "placeholder text commonly used to demonstrate the visual form "
      "of a document or a typeface without relying on meaningful content.",
      textAlign: TextAlign.justify,
      style: TextStyle(
          height: 1.5,
          fontSize: 14,
          fontWeight: FontWeight.normal,
          color: Color(0xFF2F2F3E)),
    );
  }

  Widget property() {
    return Container(
      padding: EdgeInsets.only(right: 20, left: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                "COLOR",
                textAlign: TextAlign.left,
                style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF2F2F3E)),
              ),
              spaceVertical(10),
              colorSelector(),
            ],
          ),
          size()
        ],
      ),
    );
  }

  Widget colorSelector() {
    return Container(
      child: Row(
        children: <Widget>[
          ColorTicker(
              color: Colors.blue,
              selected: selected == "blue",
              selectedCallback: () {
                setState(() {
                  selected = "blue";
                });
              }),
          ColorTicker(
              color: Colors.green,
              selected: selected == "green",
              selectedCallback: () {
                setState(() {
                  selected = "green";
                });
              }),
          ColorTicker(
            color: Colors.yellow,
            selected: selected == "yellow",
            selectedCallback: () {
              setState(() {
                selected = "yellow";
              });
            },
          ),
          ColorTicker(
            color: Colors.pink,
            selected: selected == "pink",
            selectedCallback: () {
              setState(() {
                selected = "pink";
              });
            },
          ),
        ],
      ),
    );
  }

  Widget size() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(
          "Size",
          textAlign: TextAlign.left,
          style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: Color(0xFF2F2F3E)),
        ),
        spaceVertical(10),
        Container(
          width: 70,
          padding: EdgeInsets.all(10),
          color: Color(0xFFF5F8FB),
          child: Text(
            "10.1",
            style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Color(0xFF2F2F3E)),
          ),
        )
      ],
    );
  }

  /***** End */

  ///************** UTILITY WIDGET ********************************************/
  Widget spaceVertical(double size) {
    return SizedBox(
      height: size,
    );
  }

  Widget spaceHorizontal(double size) {
    return SizedBox(
      width: size,
    );
  }
  /***** End */
}

class ColorTicker extends StatelessWidget {
  final Color color;
  final bool selected;
  final VoidCallback selectedCallback;
  ColorTicker({this.color, this.selected, this.selectedCallback});

  @override
  Widget build(BuildContext context) {
    print(selected);
    return GestureDetector(
        onTap: () {
          selectedCallback();
        },
        child: Container(
          padding: EdgeInsets.all(7),
          margin: EdgeInsets.all(5),
          width: 30,
          height: 30,
          decoration: BoxDecoration(
              shape: BoxShape.circle, color: color.withOpacity(0.7)),
          child: selected ? Image.asset("images/checker.png") : Container(),
        ));
  }
}

class CartState extends StatelessWidget{
    
    Widget build(BuildContext context){
        List<Single_prod> addedItems = Provider.of<CartNotifier>(context).items;
        double totalPrice = Provider.of<CartNotifier>(context).totalPrice;

        return Scaffold(
            appBar: AppBar(
                title: Text('My Cart'),
                backgroundColor: Colors.pink
            ),
            body: Column(
                children: [
                    ListView.builder(
                        shrinkWrap: true,
                        itemCount: addedItems.length,
                        itemBuilder: (context, index){
                            return ListTile(
                                leading: ConstrainedBox(
                                    constraints: BoxConstraints(
                                        minWidth: 44,
                                        minHeight: 44,
                                        maxWidth: 64,
                                        maxHeight: 64,
                                    ),
                                    child: Image.asset(addedItems[index].prod_pricture, fit: BoxFit.cover)),
                                title: Text(addedItems[index].prod_name),
                                subtitle: Text('P${addedItems[index].prod_price}'),
                                trailing: IconButton(
                                    icon: Icon(Icons.delete, color: Colors.pink,),
                                    onPressed: () {
                                        var itemName = addedItems[index].prod_name;
                                        Provider.of<CartNotifier>(context).clear(addedItems[index]);
                                        Scaffold.of(context).showSnackBar(
                                            SnackBar(content: Text('$itemName is removed from cart'))
                                        );
                                    },
                                ),
                            );
                        }
                    ),
                    Expanded(
                        child: Align(
                            alignment: Alignment.bottomLeft,
                            child: ListTile(
                                title: Text('Total Price of Items: '),
                                trailing: Text('P${totalPrice.toStringAsFixed(2)}'),
                            ),

                        ),
                    ),
                ],
            ),
        );
             
    }
}

//Notifier
class CartNotifier extends ChangeNotifier{
    
    List<Single_prod> _items = [];
    List<Single_prod> get items => _items;

    void add(item){
        _items.add(item);
        notifyListeners();
    }

    double get totalPrice{
        double totalPrice = 0;

        for(var i= 0;i< _items.length;i++){
            totalPrice += _items[i].prod_price;

        }
        return totalPrice;
    }

    void clear(item){
        _items.remove(item);
        notifyListeners();
    }
}